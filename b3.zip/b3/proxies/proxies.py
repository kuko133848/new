
def shaun():
    proxies = {
    "http": "http://gate.proxiware.com:2000",
    "https": "http://gate.proxiware.com:2000"
  }
    return proxies


