BOT_TOKEN = '6531211654:AAFdBqprVZBzBsvaaaGsvIgtHzNFnABjsmY'

PREFIX = "!/."

ANTISPAM = int(120)

OWNER = 743175202

APP_ID = ""

API_HASH = ''

SESSION = ""

OWNERID = int(743175202)

OWNER_NAME = "<a href='tg://user?id=743175202'>⏤͟͞𝙈𝙐𝙃𝘼𝙈𝙀𝘿</a>"

CHANNEL = "https://t.me/khatrch"

GROUP = "https://t.me/khatarteam"

OWNER_LINK = "https://t.me/U_8_M"

from database import check_user, check_admin

def check_owner(id):
  if id == OWNER: return True
def ok(id):
  if check_owner(id):
    user = "OWNER"
    return user
  if check_admin(id) == True:
    user = "ADMIN"
    return user

  elif check_user(id) == True:
    user = "PAID"
    return user

  elif check_user(id) == False or check_admin(id) == False:
    user = "FREE"
    return user

  else:
    user = "FREE"
    return user
